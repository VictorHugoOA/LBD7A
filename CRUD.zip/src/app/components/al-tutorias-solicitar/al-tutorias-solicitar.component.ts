import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-al-tutorias-solicitar',
  templateUrl: './al-tutorias-solicitar.component.html',
  styleUrls: ['./al-tutorias-solicitar.component.css']
})
export class AlTutoriasSolicitarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
